@echo off
cd /d "%~dp0"
echo Setting up Python sidecar for QuantFlow Terminal...
echo.
if not exist "python\venv\" (
    if exist "python\requirements.txt" (
        echo Creating Python virtual environment...
        python -m venv python\venv
        if errorlevel 1 (
            echo Error: Python not found. Please install Python 3.12+ and try again.
            pause
            exit /b 1
        )
        echo Installing Python dependencies...
        python\venv\Scripts\pip install -r python\requirements.txt
        if errorlevel 1 (
            echo Warning: Some dependencies failed to install.
        )
    )
) else (
    echo Python virtual environment already exists.
)
echo.
echo Setup complete. Run quantflow.exe to start.
pause
