"""
BIS (Bank for International Settlements) SDMX API wrapper
Provides access to global economic and financial statistics data from BIS

API Documentation: https://www.bis.org/statistics/about_bis_stats_data_services.htm
Base URL: https://stats.bis.org/api/v1

Key Features:
- No API key required (public data)
- SDMX 2.1 format support
- Multiple response formats (XML, JSON, CSV)
- Comprehensive time series data
- Global economic and financial statistics
"""

import asyncio
import json
import sys
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Union
from urllib.parse import urlencode, quote
import aiohttp
import html
import math


class BISError(Exception):
    """Custom exception for BIS API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, endpoint: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.endpoint = endpoint


class BISAPI:
    """BIS SDMX API client with comprehensive coverage of all endpoints"""

    def __init__(self, base_url: str = "https://stats.bis.org/api/v1", timeout: int = 30):
        self.base_url = base_url.rstrip('/')
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session = None

        # Common BIS data flows (statistical domains)
        self.known_flows = {
            "WS_EER": "Effective exchange rates",
            "WS_CBPOL": "Central bank policy rates",
            "WS_DT1": "Debt securities",
            "WS_LTINT": "Long-term interest rates",
            "WS_STINT": "Short-term interest rates",
            "WS_MON": "Monetary aggregates",
            "WS_XRU": "Exchange rates",
            "WS_CRD": "Credit to the non-financial sector",
            "WS_HP": "House prices",
            "WS_REER": "Real effective exchange rates",
            "WS_CUST": "Customs and exchange controls",
            "WS_FDI": "Foreign direct investment",
            "WS_CUR": "Currency composition of official foreign exchange reserves"
        }

        # Random user agents for requests
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        ]

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    def _get_headers(self, endpoint_type: str = "data") -> Dict[str, str]:
        """Get request headers with random user agent"""
        import random

        # Set appropriate Accept header based on endpoint type
        if endpoint_type == "structure":
            accept_header = "application/vnd.sdmx.structure+json;version=1.0.0,application/vnd.sdmx.structure+xml;version=2.1,application/xml"
        else:
            accept_header = "application/vnd.sdmx.data+json;version=1.0.0,application/vnd.sdmx.genericdata+xml;version=2.1,application/xml"

        return {
            "User-Agent": random.choice(self.user_agents),
            "Accept": accept_header,
            "Accept-Encoding": "gzip, deflate"
        }

    async def _make_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None, endpoint_type: str = "data") -> Dict[str, Any]:
        """Make HTTP request with error handling"""
        if not self.session:
            raise BISError("Session not initialized. Use async with BISAPI()...")

        url = f"{self.base_url}/{endpoint}"
        headers = self._get_headers(endpoint_type)

        try:
            async with self.session.get(url, params=params, headers=headers) as response:
                if response.status == 200:
                    content_type = response.headers.get('content-type', '')

                    if 'application/json' in content_type or 'application/vnd.sdmx.data+json' in content_type:
                        data = await response.json()
                        return self._format_response(data, endpoint)
                    elif 'application/xml' in content_type or 'text/xml' in content_type:
                        text_data = await response.text()
                        return self._parse_xml_response(text_data, endpoint)
                    elif 'text/csv' in content_type:
                        text_data = await response.text()
                        return self._parse_csv_response(text_data, endpoint)
                    else:
                        # Try to parse as JSON first, then as text
                        try:
                            data = await response.json()
                            return self._format_response(data, endpoint)
                        except:
                            text_data = await response.text()
                            return {
                                "success": True,
                                "data": text_data,
                                "content_type": content_type,
                                "endpoint": endpoint,
                                "params": params
                            }
                else:
                    error_text = await response.text()
                    raise BISError(f"HTTP {response.status}: {error_text}", response.status, endpoint)

        except asyncio.TimeoutError:
            raise BISError(f"Request timeout after {self.timeout.total} seconds", None, endpoint)
        except aiohttp.ClientError as e:
            raise BISError(f"Network error: {str(e)}", None, endpoint)
        except Exception as e:
            raise BISError(f"Unexpected error: {str(e)}", None, endpoint)

    def _format_response(self, data: Dict[str, Any], endpoint: str) -> Dict[str, Any]:
        """Format API response with metadata"""
        return {
            "success": True,
            "data": data,
            "endpoint": endpoint,
            "timestamp": datetime.now().isoformat()
        }

    def _parse_xml_response(self, xml_data: str, endpoint: str) -> Dict[str, Any]:
        """Parse XML SDMX response"""
        try:
            root = ET.fromstring(xml_data)

            # Extract basic information
            result = {
                "success": True,
                "data": {
                    "xml_raw": xml_data,
                    "root_tag": root.tag,
                    "namespaces": dict(root.attrib.items()) if hasattr(root, 'attrib') else {}
                },
                "endpoint": endpoint,
                "format": "xml"
            }

            # Try to extract series data if present
            series = root.findall('.//{http://www.sdmx.org/resources/sdmxml/schemas/v2_1/data/generic}Series')
            if series:
                result["data"]["series_count"] = len(series)
                series_data = []
                for series_elem in series[:5]:  # Limit to first 5 for preview
                    series_info = {}
                    for child in series_elem:
                        if child.tag.endswith('SeriesKey'):
                            series_info["key"] = {v.attrib.get('id'): v.text for v in child}
                        elif child.tag.endswith('Obs'):
                            obs_info = {v.attrib.get('id'): v.text for v in child}
                            series_info.setdefault("observations", []).append(obs_info)
                    series_data.append(series_info)
                result["data"]["series_preview"] = series_data

            return result

        except ET.ParseError as e:
            return {
                "success": True,
                "data": {"xml_raw": xml_data, "parse_error": str(e)},
                "endpoint": endpoint,
                "format": "xml"
            }

    def _parse_csv_response(self, csv_data: str, endpoint: str) -> Dict[str, Any]:
        """Parse CSV response"""
        lines = csv_data.strip().split('\n')
        return {
            "success": True,
            "data": {
                "csv_raw": csv_data,
                "lines_count": len(lines),
                "header": lines[0] if lines else "",
                "preview": lines[:10]  # First 10 lines as preview
            },
            "endpoint": endpoint,
            "format": "csv"
        }

    # DATA QUERY ENDPOINTS

    async def get_data(
        self,
        flow: str,
        key: str = "all",
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        first_n_observations: Optional[int] = None,
        last_n_observations: Optional[int] = None,
        detail: str = "full"
    ) -> Dict[str, Any]:
        """
        Get statistical data for a specific flow and key combination

        Args:
            flow: Statistical domain (e.g., 'WS_EER', 'BIS,WS_EER,1.0')
            key: Data key identifying series (use 'all' for all data)
            start_period: Start period (ISO 8601 or SDMX format)
            end_period: End period (ISO 8601 or SDMX format)
            first_n_observations: Return first N observations from oldest
            last_n_observations: Return last N observations from newest
            detail: Detail level ('full', 'dataonly', 'serieskeysonly', 'nodata')
        """
        params = {}
        if start_period:
            params["startPeriod"] = start_period
        if end_period:
            params["endPeriod"] = end_period
        if first_n_observations:
            params["firstNObservations"] = first_n_observations
        if last_n_observations:
            params["lastNObservations"] = last_n_observations
        if detail != "full":
            params["detail"] = detail

        # URL encode the flow and key properly
        encoded_flow = quote(flow, safe='')
        encoded_key = quote(key, safe='')

        endpoint = f"data/{encoded_flow}/{encoded_key}/all"
        return await self._make_request(endpoint, params)

    async def get_available_constraints(
        self,
        flow: str,
        key: str,
        component_id: str,
        mode: str = "exact",
        references: str = "none",
        start_period: Optional[str] = None,
        end_period: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get information about data availability for specific constraints

        Args:
            flow: Statistical domain
            key: Data key
            component_id: Dimension ID for availability info
            mode: 'exact' for current selection, 'available' for remaining valid options
            references: References to include ('none', 'all', etc.)
            start_period: Start period filter
            end_period: End period filter
        """
        params = {"mode": mode, "references": references}
        if start_period:
            params["startPeriod"] = start_period
        if end_period:
            params["endPeriod"] = end_period

        encoded_flow = quote(flow, safe='')
        encoded_key = quote(key, safe='')

        endpoint = f"availableconstraint/{encoded_flow}/{encoded_key}/all/{component_id}"
        return await self._make_request(endpoint, params, "structure")

    # STRUCTURE QUERY ENDPOINTS

    async def get_data_structures(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """
        Get data structure definitions

        Args:
            agency_id: Maintenance agency (e.g., 'BIS', 'all')
            resource_id: Resource ID or 'all'
            version: Version or 'latest' or 'all'
            references: References to include
            detail: Structure detail level
        """
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"datastructure/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_dataflows(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get dataflow definitions (available datasets)"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"dataflow/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_categorisations(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get categorisation definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"categorisation/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_content_constraints(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get content constraint definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"contentconstraint/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_actual_constraints(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get actual constraint definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"actualconstraint/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_allowed_constraints(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get allowed constraint definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"allowedconstraint/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_structures(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get general structure definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"structure/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_concept_schemes(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get concept scheme definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"conceptscheme/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_codelists(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get codelist definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"codelist/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_category_schemes(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get category scheme definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"categoryscheme/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_hierarchical_codelists(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get hierarchical codelist definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"hierarchicalcodelist/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    async def get_agency_schemes(
        self,
        agency_id: str = "all",
        resource_id: str = "all",
        version: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get agency scheme definitions"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')

        endpoint = f"agencyscheme/{agency_id}/{resource_id}/{version}"
        return await self._make_request(endpoint, params, "structure")

    # ITEM QUERY ENDPOINTS

    async def get_concepts(
        self,
        agency_id: str,
        resource_id: str,
        version: str,
        item_id: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get specific concepts from concept schemes"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')
        item_id = quote(item_id, safe='')

        endpoint = f"conceptscheme/{agency_id}/{resource_id}/{version}/{item_id}"
        return await self._make_request(endpoint, params, "structure")

    async def get_codes(
        self,
        agency_id: str,
        resource_id: str,
        version: str,
        item_id: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get specific codes from codelists"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')
        item_id = quote(item_id, safe='')

        endpoint = f"codelist/{agency_id}/{resource_id}/{version}/{item_id}"
        return await self._make_request(endpoint, params, "structure")

    async def get_categories(
        self,
        agency_id: str,
        resource_id: str,
        version: str,
        item_id: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get specific categories from category schemes"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')
        item_id = quote(item_id, safe='')

        endpoint = f"categoryscheme/{agency_id}/{resource_id}/{version}/{item_id}"
        return await self._make_request(endpoint, params, "structure")

    async def get_hierarchies(
        self,
        agency_id: str,
        resource_id: str,
        version: str,
        item_id: str = "all",
        references: str = "none",
        detail: str = "full"
    ) -> Dict[str, Any]:
        """Get specific hierarchies from hierarchical codelists"""
        params = {"references": references, "detail": detail}

        agency_id = quote(agency_id, safe='')
        resource_id = quote(resource_id, safe='')
        version = quote(version, safe='')
        item_id = quote(item_id, safe='')

        endpoint = f"hierarchicalcodelist/{agency_id}/{resource_id}/{version}/{item_id}"
        return await self._make_request(endpoint, params, "structure")

    # CONVENIENCE METHODS FOR COMMON DATA TYPES

    async def get_effective_exchange_rates(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """
        Get effective exchange rates data (WS_EER)

        Args:
            countries: List of country codes (e.g., ['US', 'GB', 'JP'])
            start_period: Start period
            end_period: End period
            detail: Detail level
        """
        key = "all"
        if countries:
            # Build key with country codes
            # Format example: M.N.B.US+GB+JP
            key = f"M.N.B.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_EER",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_central_bank_policy_rates(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """
        Get central bank policy rates (WS_CBPOL)

        Args:
            countries: List of country codes
            start_period: Start period
            end_period: End period
            detail: Detail level
        """
        key = "all"
        if countries:
            key = f"D.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_CBPOL",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_long_term_interest_rates(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """Get long-term interest rates (WS_LTINT)"""
        key = "all"
        if countries:
            key = f"M.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_LTINT",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_short_term_interest_rates(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """Get short-term interest rates (WS_STINT)"""
        key = "all"
        if countries:
            key = f"M.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_STINT",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_exchange_rates(
        self,
        currency_pairs: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """
        Get exchange rates (WS_XRU)

        Args:
            currency_pairs: List of currency pairs (e.g., ['USD', 'EUR', 'GBP'])
            start_period: Start period
            end_period: End period
            detail: Detail level
        """
        key = "all"
        if currency_pairs:
            key = f"D.{'+'.join(currency_pairs)}"

        return await self.get_data(
            flow="WS_XRU",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_credit_to_non_financial_sector(
        self,
        countries: Optional[List[str]] = None,
        sectors: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """
        Get credit to non-financial sector (WS_CRD)

        Args:
            countries: List of country codes
            sectors: List of sectors
            start_period: Start period
            end_period: End period
            detail: Detail level
        """
        key = "all"
        if countries and sectors:
            # Example format: Q.US.GBFC+GBFCNP+GBFCP
            key = f"Q.{'+'.join(countries)}.{'+'.join(sectors)}"
        elif countries:
            key = f"Q.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_CRD",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_house_prices(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None,
        detail: str = "dataonly"
    ) -> Dict[str, Any]:
        """Get house price indices (WS_HP)"""
        key = "all"
        if countries:
            key = f"Q.{'+'.join(countries)}"

        return await self.get_data(
            flow="WS_HP",
            key=key,
            start_period=start_period,
            end_period=end_period,
            detail=detail
        )

    async def get_available_datasets(self) -> Dict[str, Any]:
        """Get overview of all available dataflows (datasets)"""
        return await self.get_dataflows(agency_id="BIS", detail="allstubs")

    async def get_summary(self) -> Dict[str, Any]:
        """Get latest values for all BIS dataflows (for card display).
        
        Fetches the most recent data point in parallel for each dataflow,
        returns them as {dataflow_id: {latest_value, unit, date}}.
        """
        catalog = await self.get_available_datasets()
        flows = catalog.get("data", {}).get("data", {}).get("dataflows", [])
        if not flows:
            return {"success": False, "error": "No dataflows found", "dataflows": []}

        async def _latest_for_flow(flow_id: str) -> tuple:
            try:
                raw = await self.get_data(flow_id, "all", last_n_observations=1, detail="dataonly")
                sdmx = raw.get("data", {}).get("data", raw.get("data", {}))
                datasets = sdmx.get("dataSets", [])
                ds = datasets[0] if datasets else {}
                reporting_end = ds.get("reportingEnd", "")
                date_str = reporting_end[:10] if reporting_end else ""
                series_map = ds.get("series", {})
                for sk, sv in series_map.items():
                    obs = sv.get("observations", {})
                    for ok, ov in obs.items():
                        val = ov[0] if isinstance(ov, list) and ov else None
                        if val is not None:
                            fv = float(val)
                            if not math.isnan(fv):
                                return (flow_id, fv, "", date_str)
                return (flow_id, None, "", "")
            except Exception:
                return (flow_id, None, "", "")

        tasks = [_latest_for_flow(f["id"]) for f in flows]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        values = {}
        for r in results:
            if isinstance(r, tuple) and len(r) == 4:
                fid, val, unit, date = r
                if val is not None:
                    values[fid] = {"latest_value": val, "unit": unit, "date": date}

        # Merge values into the catalog flows
        enriched = []
        for f in flows:
            entry = {"id": f["id"], "name": f.get("name", f["id"]), "names": f.get("names", {})}
            vid = f["id"]
            if vid in values:
                entry["latest_value"] = values[vid]["latest_value"]
                entry["unit"] = values[vid]["unit"]
                entry["latest_date"] = values[vid]["date"]
            else:
                entry["latest_value"] = None
                entry["unit"] = ""
                entry["latest_date"] = ""
            enriched.append(entry)

        return {"success": True, "dataflows": enriched, "timestamp": int(time.time())}

    async def search_datasets(
        self,
        query: str,
        agency_id: str = "BIS"
    ) -> Dict[str, Any]:
        """
        Search for datasets matching a query

        Args:
            query: Search term
            agency_id: Agency to search in
        """
        # Get all dataflows and search through them
        result = await self.get_dataflows(agency_id=agency_id, detail="full")

        if result.get("success") and "data" in result:
            dataflows = result["data"]
            # Simple text search in the response
            matches = []
            if isinstance(dataflows, dict):
                for key, value in dataflows.items():
                    if query.lower() in str(value).lower():
                        matches.append({key: value})

            return {
                "success": True,
                "data": {
                    "query": query,
                    "matches": matches,
                    "total_matches": len(matches)
                },
                "endpoint": "search"
            }

        return result

    # COMPREHENSIVE ANALYSIS METHODS

    async def get_economic_overview(
        self,
        countries: Optional[List[str]] = None,
        start_period: Optional[str] = None,
        end_period: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get comprehensive economic overview for countries

        Args:
            countries: List of country codes
            start_period: Start period
            end_period: End period
        """
        results = {}

        # Get multiple economic indicators
        indicators = [
            ("effective_exchange_rates", self.get_effective_exchange_rates),
            ("central_bank_policy_rates", self.get_central_bank_policy_rates),
            ("long_term_interest_rates", self.get_long_term_interest_rates),
            ("short_term_interest_rates", self.get_short_term_interest_rates),
            ("exchange_rates", self.get_exchange_rates),
            ("credit_to_non_financial_sector", self.get_credit_to_non_financial_sector)
        ]

        for name, method in indicators:
            try:
                result = await method(
                    countries=countries,
                    start_period=start_period,
                    end_period=end_period,
                    detail="dataonly"
                )
                results[name] = result
            except Exception as e:
                results[name] = {"success": False, "error": str(e)}

        return {
            "success": True,
            "data": {
                "economic_overview": results,
                "countries": countries or ["all"],
                "period": {
                    "start": start_period or "earliest",
                    "end": end_period or "latest"
                },
                "indicators_requested": len(indicators),
                "indicators_retrieved": len([r for r in results.values() if r.get("success", False)])
            },
            "endpoint": "economic_overview"
        }

    async def get_dataset_metadata(
        self,
        flow: str
    ) -> Dict[str, Any]:
        """
        Get comprehensive metadata for a specific dataset

        Args:
            flow: Data flow identifier (e.g., 'WS_EER')
        """
        results = {}

        try:
            # Get dataflow information
            dataflows = await self.get_dataflows(resource_id=flow)
            results["dataflow"] = dataflows

            # Get data structure
            structures = await self.get_data_structures(resource_id=flow)
            results["structure"] = structures

            # Get sample data to understand the format
            sample_data = await self.get_data(flow=flow, detail="serieskeysonly", last_n_observations=5)
            results["sample_keys"] = sample_data

            return {
                "success": True,
                "data": {
                    "flow": flow,
                    "metadata": results,
                    "description": self.known_flows.get(flow, "Unknown dataset")
                },
                "endpoint": "dataset_metadata"
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "endpoint": "dataset_metadata"
            }


# CLI Interface
async def main():
    """CLI interface for BIS API"""
    args = sys.argv[1:]

    if len(args) < 1:
        print(json.dumps({
            "error": "Usage: python bis_data.py <command> [args...]",
            "available_commands": [
                "get_data <flow> [key] [start_period] [end_period]",
                "get_effective_exchange_rates [countries...] [start_period] [end_period]",
                "get_central_bank_policy_rates [countries...] [start_period] [end_period]",
                "get_long_term_interest_rates [countries...] [start_period] [end_period]",
                "get_short_term_interest_rates [countries...] [start_period] [end_period]",
                "get_exchange_rates [currencies...] [start_period] [end_period]",
                "get_credit_to_non_financial_sector [countries...] [sectors...] [start_period] [end_period]",
                "get_house_prices [countries...] [start_period] [end_period]",
                "get_available_datasets",
                "get_data_structures [agency_id] [resource_id] [version]",
                "search_datasets <query>",
                "get_economic_overview [countries...] [start_period] [end_period]",
                "get_dataset_metadata <flow>"
            ]
        }))
        return

    command = args[0]

    async with BISAPI() as bis:
        try:
            if command == "fetch":
                # Simplified fetch command for Fincept Terminal Economics tab
                # Usage: fetch <dataflow> <country_code> [start_period] [end_period]
                # Returns flattened [{date, value}] array for charting
                if len(args) < 3:
                    raise ValueError("Usage: fetch <dataflow> <country_code> [start_period] [end_period]")

                dataflow = args[1]
                country_code = args[2]
                start_period = args[3] if len(args) > 3 else None
                end_period = args[4] if len(args) > 4 else None

                # Key patterns per dataflow — each flow has different dimension layouts
                # Format: dots separate dimension positions, country goes in the right slot
                KEY_PATTERNS = {
                    # FREQ.REF_AREA
                    "WS_CBPOL": "M.{cc}",
                    # FREQ.EER_TYPE.EER_BASKET.REF_AREA
                    "WS_EER": "M.N.B.{cc}",
                    "WS_EER_R": "M.R.B.{cc}",
                    # FREQ.REF_AREA.CURRENCY.COLLECTION
                    "WS_XRU": "M.{cc}",
                    # FREQ.REF_AREA.UNIT_MEASURE
                    "WS_LONG_CPI": "M.{cc}",
                    # FREQ.REF_AREA.COMP_METHOD.UNIT_MEASURE.CURRENCY.TRANSFORMATION
                    "WS_CBTA": "Q.{cc}",
                    # FREQ.BORROWERS_CTY...
                    "WS_CREDIT_GAP": "Q.{cc}",
                    "WS_TC": "Q.{cc}",
                    "WS_DSR": "Q.{cc}",
                    # FREQ.CURR_DENOM.BORROWERS_CTY...
                    "WS_GLI": "Q..{cc}",
                    # FREQ.REF_AREA.VALUE.UNIT_MEASURE
                    "WS_SPP": "Q.{cc}",
                    "WS_CPP": "Q.{cc}",
                    "WS_DPP": "Q.{cc}",
                    # FREQ.L_MEASURE.L_REP_CTY...
                    "WS_CBS_PUB": "Q..{cc}",
                    "WS_LBS_D_PUB": "Q..{cc}",
                    # FREQ.ISSUER_RES...
                    "WS_DEBT_SEC2_PUB": "Q.{cc}",
                    # FREQ.ADJUSTMENT.REF_AREA...
                    "WS_NA_SEC_DSS": "Q..{cc}",
                    # OTC/exchange-traded derivatives — global, no country filter
                    "WS_OTC_DERIV2": "H",
                    "WS_DER_OTC_TOV": "T",
                    "WS_XTD_DERIV": "Q",
                    # CPMI flows — annual, country in REP_CTY pos 2
                    "WS_CPMI_MACRO": "A..{cc}",
                    "WS_CPMI_CASHLESS": "A..{cc}",
                    "WS_CPMI_CT1": "A..{cc}",
                    "WS_CPMI_CT2": "A..{cc}",
                    "WS_CPMI_DEVICES": "A..{cc}",
                    "WS_CPMI_INSTITUT": "A..{cc}",
                    "WS_CPMI_PARTICIP": "A..{cc}",
                    "WS_CPMI_SYSTEMS": "A..{cc}",
                }

                pattern = KEY_PATTERNS.get(dataflow, "M.{cc}")
                if country_code and country_code != "all":
                    key = pattern.format(cc=country_code)
                else:
                    key = pattern.format(cc="")

                raw = await bis.get_data(dataflow, key, start_period, end_period)

                if not raw.get("success"):
                    result = raw
                else:
                    # Flatten SDMX-JSON into simple [{date, value}] for charting
                    flat_data = []
                    try:
                        resp = raw.get("data", {})
                        sdmx_data = resp.get("data", resp)
                        datasets = sdmx_data.get("dataSets", [])
                        structure = sdmx_data.get("structure", resp.get("structure", {}))
                        obs_dims = structure.get("dimensions", {}).get("observation", [])

                        # Get time period values from observation dimension
                        time_values = {}
                        if obs_dims:
                            time_values = {str(i): v.get("id", v.get("name", str(i)))
                                           for i, v in enumerate(obs_dims[0].get("values", []))}

                        for ds in datasets:
                            series_map = ds.get("series", {})
                            for _series_key, series_val in series_map.items():
                                observations = series_val.get("observations", {})
                                for obs_key, obs_val in observations.items():
                                    period = time_values.get(obs_key, obs_key)
                                    value = obs_val[0] if isinstance(obs_val, list) and obs_val else None
                                    if value is not None:
                                        try:
                                            value = float(value)
                                            import math
                                            if math.isnan(value) or math.isinf(value):
                                                continue
                                        except (ValueError, TypeError):
                                            continue
                                        flat_data.append({"date": str(period), "value": value})

                        # Deduplicate by date (average if multiple series for same date)
                        from collections import defaultdict
                        date_vals = defaultdict(list)
                        for d in flat_data:
                            date_vals[d["date"]].append(d["value"])
                        flat_data = [{"date": dt, "value": round(sum(vs)/len(vs), 6)}
                                     for dt, vs in sorted(date_vals.items())]

                    except Exception as parse_err:
                        result = {"success": False, "error": f"Failed to parse SDMX response: {str(parse_err)}"}
                        print(json.dumps(result, indent=2))
                        return

                    result = {
                        "success": True,
                        "data": flat_data,
                        "metadata": {
                            "dataflow": dataflow,
                            "country": country_code,
                            "source": "BIS"
                        }
                    }

            elif command == "get_data":
                if len(args) < 2:
                    raise ValueError("Usage: get_data <flow> [key] [start_period] [end_period]")

                flow = args[1]
                key = args[2] if len(args) > 2 else "all"
                start_period = args[3] if len(args) > 3 else None
                end_period = args[4] if len(args) > 4 else None

                result = await bis.get_data(flow, key, start_period, end_period)

            elif command == "get_effective_exchange_rates":
                countries = []
                other_args = []

                # Parse arguments - country codes are 2-letter, others are dates
                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_effective_exchange_rates(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_central_bank_policy_rates":
                countries = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_central_bank_policy_rates(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_long_term_interest_rates":
                countries = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_long_term_interest_rates(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_short_term_interest_rates":
                countries = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_short_term_interest_rates(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_exchange_rates":
                currencies = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 3 and arg.isalpha():
                        currencies.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_exchange_rates(
                    currency_pairs=currencies if currencies else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_credit_to_non_financial_sector":
                countries = []
                sectors = []
                other_args = []

                # Parse arguments - need to distinguish countries from sectors
                # This is simplified - in practice, you might need more sophisticated parsing
                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        sectors.append(arg)

                # Last two arguments might be dates
                if len(other_args) >= 2:
                    start_period = other_args[-2]
                    end_period = other_args[-1]
                    sectors = sectors[:-2]
                elif len(other_args) == 1:
                    start_period = other_args[0]
                    end_period = None
                    sectors = sectors[:-1]
                else:
                    start_period = None
                    end_period = None

                result = await bis.get_credit_to_non_financial_sector(
                    countries=countries if countries else None,
                    sectors=sectors if sectors else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_house_prices":
                countries = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_house_prices(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_available_datasets":
                result = await bis.get_available_datasets()

            elif command == "get_summary":
                result = await bis.get_summary()

            elif command == "get_data_structures":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"

                result = await bis.get_data_structures(agency_id, resource_id, version)

            elif command == "search_datasets":
                if len(args) < 3:
                    raise ValueError("Usage: search_datasets <query>")
                query = args[1]
                result = await bis.search_datasets(query)

            elif command == "get_economic_overview":
                countries = []
                other_args = []

                for arg in sys.argv[2:]:
                    if len(arg) == 2 and arg.isalpha():
                        countries.append(arg)
                    else:
                        other_args.append(arg)

                start_period = other_args[0] if len(other_args) > 0 else None
                end_period = other_args[1] if len(other_args) > 1 else None

                result = await bis.get_economic_overview(
                    countries=countries if countries else None,
                    start_period=start_period,
                    end_period=end_period
                )

            elif command == "get_dataset_metadata":
                if len(args) < 3:
                    raise ValueError("Usage: get_dataset_metadata <flow>")
                flow = args[1]
                result = await bis.get_dataset_metadata(flow)

            elif command == "get_available_constraints":
                if len(args) < 5:
                    raise ValueError("Usage: get_available_constraints <flow> <key> <component_id> [mode] [references]")
                flow = args[1]
                key = args[2]
                component_id = args[3]
                mode = args[4] if len(args) > 5 else "exact"
                references = sys.argv[6] if len(args) > 6 else "none"
                result = await bis.get_available_constraints(flow, key, component_id, mode, references)

            elif command == "get_dataflows":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_dataflows(agency_id, resource_id, version, references, detail)

            elif command == "get_categorisations":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_categorisations(agency_id, resource_id, version, references, detail)

            elif command == "get_content_constraints":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_content_constraints(agency_id, resource_id, version, references, detail)

            elif command == "get_actual_constraints":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_actual_constraints(agency_id, resource_id, version, references, detail)

            elif command == "get_allowed_constraints":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_allowed_constraints(agency_id, resource_id, version, references, detail)

            elif command == "get_structures":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_structures(agency_id, resource_id, version, references, detail)

            elif command == "get_concept_schemes":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_concept_schemes(agency_id, resource_id, version, references, detail)

            elif command == "get_codelists":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_codelists(agency_id, resource_id, version, references, detail)

            elif command == "get_category_schemes":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_category_schemes(agency_id, resource_id, version, references, detail)

            elif command == "get_hierarchical_codelists":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_hierarchical_codelists(agency_id, resource_id, version, references, detail)

            elif command == "get_agency_schemes":
                agency_id = args[1] if len(args) > 2 else "all"
                resource_id = args[2] if len(args) > 3 else "all"
                version = args[3] if len(args) > 4 else "all"
                references = args[4] if len(args) > 5 else "none"
                detail = sys.argv[6] if len(args) > 6 else "full"
                result = await bis.get_agency_schemes(agency_id, resource_id, version, references, detail)

            elif command == "get_concepts":
                if len(args) < 4:
                    raise ValueError("Usage: get_concepts <agency_id> <resource_id> <version> [item_id] [references] [detail]")
                agency_id = args[1]
                resource_id = args[2]
                version = args[3]
                item_id = args[4] if len(args) > 5 else "all"
                references = sys.argv[6] if len(args) > 6 else "none"
                detail = sys.argv[7] if len(args) > 7 else "full"
                result = await bis.get_concepts(agency_id, resource_id, version, item_id, references, detail)

            elif command == "get_codes":
                if len(args) < 4:
                    raise ValueError("Usage: get_codes <agency_id> <resource_id> <version> [item_id] [references] [detail]")
                agency_id = args[1]
                resource_id = args[2]
                version = args[3]
                item_id = args[4] if len(args) > 5 else "all"
                references = sys.argv[6] if len(args) > 6 else "none"
                detail = sys.argv[7] if len(args) > 7 else "full"
                result = await bis.get_codes(agency_id, resource_id, version, item_id, references, detail)

            elif command == "get_categories":
                if len(args) < 4:
                    raise ValueError("Usage: get_categories <agency_id> <resource_id> <version> [item_id] [references] [detail]")
                agency_id = args[1]
                resource_id = args[2]
                version = args[3]
                item_id = args[4] if len(args) > 5 else "all"
                references = sys.argv[6] if len(args) > 6 else "none"
                detail = sys.argv[7] if len(args) > 7 else "full"
                result = await bis.get_categories(agency_id, resource_id, version, item_id, references, detail)

            elif command == "get_hierarchies":
                if len(args) < 4:
                    raise ValueError("Usage: get_hierarchies <agency_id> <resource_id> <version> [item_id] [references] [detail]")
                agency_id = args[1]
                resource_id = args[2]
                version = args[3]
                item_id = args[4] if len(args) > 5 else "all"
                references = sys.argv[6] if len(args) > 6 else "none"
                detail = sys.argv[7] if len(args) > 7 else "full"
                result = await bis.get_hierarchies(agency_id, resource_id, version, item_id, references, detail)

            else:
                result = {
                    "success": False,
                    "error": f"Unknown command: {command}",
                    "available_commands": [
                        "get_data", "get_effective_exchange_rates", "get_central_bank_policy_rates",
                        "get_long_term_interest_rates", "get_short_term_interest_rates",
                        "get_exchange_rates", "get_credit_to_non_financial_sector", "get_house_prices",
                        "get_available_datasets", "get_data_structures", "search_datasets",
                        "get_economic_overview", "get_dataset_metadata", "get_available_constraints",
                        "get_dataflows", "get_categorisations", "get_content_constraints",
                        "get_actual_constraints", "get_allowed_constraints", "get_structures",
                        "get_concept_schemes", "get_codelists", "get_category_schemes",
                        "get_hierarchical_codelists", "get_agency_schemes", "get_concepts",
                        "get_codes", "get_categories", "get_hierarchies"
                    ]
                }

            print(json.dumps(result, indent=2))

        except BISError as e:
            error_response = {
                "success": False,
                "error": str(e),
                "endpoint": e.endpoint,
                "status_code": e.status_code
            }
            print(json.dumps(error_response, indent=2))

        except Exception as e:
            error_response = {
                "success": False,
                "error": str(e),
                "command": command
            }
            print(json.dumps(error_response, indent=2))


if __name__ == "__main__":
    asyncio.run(main())