"""GTJA Alpha 160 (国泰君安 191 短周期交易型 alpha 因子, 2014).

Formula (verbatim from the report):
    SMA((CLOSE<=DELAY(CLOSE,1)?STD(CLOSE,20):0),20,1)

Notes: 
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src.factors.base import (
    decay_linear,
    delta,
    rank,
    safe_div,
    scale,
    signed_power,
    ts_argmax,
    ts_argmin,
    ts_corr,
    ts_cov,
    ts_max,
    ts_mean,
    ts_min,
    ts_rank,
    ts_std,
)

ALPHA_ID = "gtja191_160"

__alpha_meta__ = {
    'id': 'gtja191_160',
    'theme': ['volatility'],
    'formula_latex': 'sma((c<=delay(c,1)?std(c,20):0),20,1)',
    'columns_required': ['close'],
    'extras_required': [],
    'universe': ['equity_cn'],
    'frequency': ['1d'],
    'decay_horizon': 20,
    'min_warmup_bars': 22,
    'notes': '',
}


def compute(panel):
    """Compute gtja191_160.

    Args:
        panel: dict[str, pd.DataFrame] with at least the required columns.

    Returns:
        pd.DataFrame with index = panel["close"].index, columns = panel["close"].columns.
    """
    def _sma(x, n, m):
        """SMA(x, n, m) per GTJA convention -> ewm with alpha = m/n."""
        return x.ewm(alpha=m / n, adjust=False).mean()
    c = panel["close"]
    cond = (c <= c.shift(1)).astype("float64")
    out = _sma(ts_std(c, 20) * cond, 20, 1)
    return out
