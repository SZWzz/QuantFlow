"""缠论分析器主入口。

ChanlunAnalyser 接收 外部 TDX 项目 的 K 线 DataFrame，
内部执行完整的缠论计算管道：
K线合并 → 分型识别 → 笔计算 → 中枢计算 → 线段 → 买卖点 → 背驰。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import pandas as pd

from .beichi import check_bi_beichi  # noqa: F401
from .bi import find_bis
from .config import ChanlunConfig
from .fractal import find_fractals
from .kline_merge import merge_klines
from .macd import calc_macd  # noqa: F401
from .mmd import find_mmds  # noqa: F401
from .types import BC, BI, FX, MMD, XD, ZS, CLKline, Kline
from .xd import find_xds  # noqa: F401
from .zs import find_zss


def _df_to_klines(df: pd.DataFrame) -> list[Kline]:
    """将 外部 TDX 项目 K 线 DataFrame 转为缠论 Kline 列表。

    期望 DataFrame 包含列：datetime, open, close, high, low, vol
    """
    klines: list[Kline] = []
    for i, row in enumerate(df.itertuples()):
        dt = getattr(row, "datetime", None) or getattr(row, "date", None)
        if dt is None:
            continue
        row_any: Any = row  # avoid pandas-stubs vs bare pandas type mismatch
        vol = getattr(row, "vol", 0.0) or 0.0
        klines.append(
            Kline(
                index=i,
                date=dt,
                open=float(row_any.open),
                close=float(row_any.close),
                high=float(row_any.high),
                low=float(row_any.low),
                amount=float(vol),
            )
        )
    return klines


@dataclass
class ChanlunResult:
    """缠论分析结果。"""

    code: str = ""
    frequency: str = ""
    klines: list[Kline] = field(default_factory=list)
    cklines: list[CLKline] = field(default_factory=list)
    fractals: list[FX] = field(default_factory=list)
    bis: list[BI] = field(default_factory=list)
    zss: list[ZS] = field(default_factory=list)
    xds: list[XD] = field(default_factory=list)
    mmds: list[MMD] = field(default_factory=list)
    bcs: list[BC] = field(default_factory=list)
    macd: dict[str, list[float]] = field(default_factory=dict)

    def _fmt_dt(self, dt: datetime) -> str:
        """按 frequency 自适应格式化日期。

        分钟级别（1/5/15/30/60min）输出完整时分 YYYY-MM-DD HH:MM，
        日/周/月/年级别只输出日期 YYYY-MM-DD（无多余 00:00）。
        frequency 来自 CLI 原始值（如 5MIN/30MIN）或 Web 映射值（5min/30min），
        统一转小写后判断是否含 'min'。
        """
        fmt = "%Y-%m-%d %H:%M" if "min" in self.frequency.lower() else "%Y-%m-%d"
        return dt.strftime(fmt)

    def to_dict(self) -> dict[str, Any]:
        """将结果转为可序列化的字典（用于 JSON 输出）。"""
        return {
            "code": self.code,
            "frequency": self.frequency,
            "kline_count": len(self.klines),
            "ckline_count": len(self.cklines),
            "fractal_count": len(self.fractals),
            "bi_count": len(self.bis),
            "zs_count": len(self.zss),
            "xd_count": len(self.xds),
            "mmd_count": len(self.mmds),
            "bc_count": len(self.bcs),
            "bis": [
                {
                    "index": bi.index,
                    "direction": bi.direction.value,
                    "start_date": self._fmt_dt(bi.start.k.date),
                    "end_date": self._fmt_dt(bi.end.k.date),
                    "high": round(bi.high, 2),
                    "low": round(bi.low, 2),
                    "done": bi.is_done(),
                }
                for bi in self.bis
            ],
            "zss": [
                {
                    "index": zs.index,
                    "zg": round(zs.zg, 2),
                    "zd": round(zs.zd, 2),
                    "gg": round(zs.gg, 2),
                    "dd": round(zs.dd, 2),
                    "line_count": zs.line_count,
                    "start_date": self._fmt_dt(zs.start.k.date) if zs.start else None,
                    "end_date": self._fmt_dt(zs.end.k.date) if zs.end else None,
                    "done": zs.done,
                }
                for zs in self.zss
            ],
            "xds": [
                {
                    "index": xd.index,
                    "direction": xd.direction.value,
                    "start_date": self._fmt_dt(xd.start.k.date),
                    "end_date": self._fmt_dt(xd.end.k.date),
                    "high": round(xd.high, 2),
                    "low": round(xd.low, 2),
                }
                for xd in self.xds
            ],
            "mmds": [
                {
                    "type": mmd.mmd_type.value,
                    "date": self._fmt_dt(mmd.bi.end.k.date) if mmd.bi else None,
                    "msg": mmd.msg,
                }
                for mmd in self.mmds
            ],
            "bcs": [
                {
                    "type": bc.bc_type.value,
                    "bc": bc.bc,
                    "curr_date": self._fmt_dt(bc.curr.end.k.date) if bc.curr else None,
                    "prev_date": self._fmt_dt(bc.prev.end.k.date) if bc.prev else None,
                    "msg": bc.msg,
                }
                for bc in self.bcs
            ],
        }


class ChanlunAnalyser:
    """缠论分析器。

    接收 外部 TDX 项目 K 线 DataFrame，执行缠论计算管道。

    用法：
        analyser = ChanlunAnalyser("SZ000001", "DAILY")
        analyser.process_klines(df)
        result = analyser.result
    """

    def __init__(
        self,
        code: str = "",
        frequency: str = "",
        config: ChanlunConfig | None = None,
    ) -> None:
        self._code = code
        self._frequency = frequency
        self._config = config or ChanlunConfig()
        self._result = ChanlunResult(
            code=code,
            frequency=frequency,
        )
        self._prev_df: pd.DataFrame | None = None

    @property
    def config(self) -> ChanlunConfig:
        return self._config

    @property
    def result(self) -> ChanlunResult:
        return self._result

    def process_klines(self, df: pd.DataFrame) -> ChanlunResult:
        """处理 K 线 DataFrame，执行缠论计算管道。

        Args:
            df: 外部 TDX 项目 返回的 K 线 DataFrame

        Returns:
            ChanlunResult 包含所有缠论计算结果
        """
        self._prev_df = df.copy()
        # Step 1: DataFrame → Kline 列表
        klines = _df_to_klines(df)
        self._result.klines = klines

        if not klines:
            return self._result

        # Step 2: K线包含处理
        cklines = merge_klines(klines)
        self._result.cklines = cklines

        # Step 3: 分型识别
        fractals = find_fractals(cklines, self._config)
        self._result.fractals = fractals

        # Step 4: 笔计算
        bis = find_bis(fractals, self._config)
        self._result.bis = bis

        # Step 5: 中枢计算
        zss = find_zss(bis, self._config)
        self._result.zss = zss

        # Step 6: MACD 计算
        closes = [k.close for k in klines]
        self._result.macd = calc_macd(
            closes, self._config.macd_fast, self._config.macd_slow, self._config.macd_signal
        )

        # Step 7: 线段计算
        xds = find_xds(bis, self._config)
        self._result.xds = xds

        # Step 8: 买卖点识别
        mmds = find_mmds(bis, zss, self._config)
        self._result.mmds = mmds

        # Step 9: 背驰判断
        bcs = check_bi_beichi(bis, zss, self._config)
        self._result.bcs = bcs

        return self._result

    def append_klines(self, df_new: pd.DataFrame) -> ChanlunResult:
        """增量追加 K 线数据并重新计算。

        将新数据追加到之前处理过的 DataFrame 后面，
        然后在完整数据上重新执行缠论计算管道。

        相比手动拼接 + process_klines 的优势：
        - API 更简洁，无需用户管理 DataFrame 拼接
        - 未来可优化为只重新计算受影响的部分

        Args:
            df_new: 新增的 K 线 DataFrame

        Returns:
            更新后的 ChanlunResult

        Raises:
            RuntimeError: 如果之前没有调用过 process_klines
        """
        if self._prev_df is None:
            msg = "请先调用 process_klines() 初始化，再使用 append_klines()"
            raise RuntimeError(msg)

        # 拼接旧数据 + 新数据
        combined = pd.concat([self._prev_df, df_new], ignore_index=True)

        # 去重（防止重复追加）
        if "datetime" in combined.columns:
            combined = combined.drop_duplicates(subset=["datetime"], keep="last")
            combined = combined.reset_index(drop=True)

        return self.process_klines(combined)

    def get_bis(self) -> list[BI]:
        return self._result.bis

    def get_zss(self) -> list[ZS]:
        return self._result.zss

    def get_fxs(self) -> list[FX]:
        return self._result.fractals

    def get_klines(self) -> list[Kline]:
        return self._result.klines

    def get_cklines(self) -> list[CLKline]:
        return self._result.cklines
