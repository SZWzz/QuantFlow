@echo off
cd /d "%~dp0"
echo QuantFlow Terminal starting...
echo.
if not exist "python\venv\" (
    echo Python sidecar not set up. Run setup_python.bat first.
    echo Core features will work without it.
)
start quantflow.exe
